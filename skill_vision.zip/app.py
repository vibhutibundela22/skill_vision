# Placeholder for app.py
from flask import Flask, render_template, redirect, url_for, flash, request, session
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from forms import RegistrationForm, LoginForm
from models import db, User, QuizQuestion, QuizScore
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///site.db'  # Change to PostgreSQL URI when deploying
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db.init_app(app)
bcrypt = Bcrypt(app)

@app.before_first_request
def create_tables():
    db.create_all()

@app.route('/')
def index():
    if 'user_id' in session:
        return render_template('dashboard.html', username=session.get('username'))
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_pw = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_pw)
        db.session.add(user)
        db.session.commit()
        flash('Account created!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and bcrypt.check_password_hash(user.password, form.password.data):
            session['user_id'] = user.id
            session['username'] = user.username
            flash('Logged in!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Login Failed. Check email or password.', 'danger')
    return render_template('login.html', form=form)

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/quiz/<topic>', methods=['GET', 'POST'])
def quiz(topic):
    if 'user_id' not in session:
        return redirect(url_for('login'))

    questions = QuizQuestion.query.filter_by(topic=topic).all()
    if request.method == 'POST':
        score = 0
        for q in questions:
            if request.form.get(str(q.id)) == q.correct_option:
                score += 1
        quiz_score = QuizScore(user_id=session['user_id'], topic=topic, score=score)
        db.session.add(quiz_score)
        db.session.commit()
        return render_template('quiz_result.html', score=score, total=len(questions))
    return render_template('quiz.html', questions=questions, topic=topic)

@app.route('/leaderboard')
def leaderboard():
    scores = QuizScore.query.order_by(QuizScore.score.desc()).all()
    return render_template('leaderboard.html', scores=scores)

if __name__ == '__main__':
    app.run(debug=True)
